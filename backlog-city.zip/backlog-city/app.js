(function () {
  "use strict";
  const CFG = window.BC_CONFIG || {};

  const SAMPLE = [
    { name: "The Witcher 3", played: 22, left: 80 },
    { name: "Baldur's Gate 3", played: 14, left: 86 },
    { name: "Hollow Knight", played: 6, left: 30 },
    { name: "Elden Ring", played: 0, left: 60 },
    { name: "Hades", played: 18, left: 7 },
    { name: "Celeste", played: 0, left: 9 },
    { name: "Persona 5 Royal", played: 31, left: 70 },
    { name: "Disco Elysium", played: 3, left: 24 },
    { name: "Stardew Valley", played: 40, left: 15 },
    { name: "Outer Wilds", played: 0, left: 17 },
    { name: "Red Dead Redemption 2", played: 12, left: 38 },
    { name: "Portal 2", played: 4, left: 5 },
    { name: "Cyberpunk 2077", played: 0, left: 26 },
    { name: "Inside", played: 0, left: 4 }
  ];
  const sampleGames = () => SAMPLE.map((g, i) => ({ id: i + 1, name: g.name, played: g.played, left: g.left, done: false }));

  const KEY = "backlog-city-v2";
  const defaults = { games: sampleGames(), source: "sample", persona: "", profile: "", pace: 8, avgLen: 20, nightPick: 2 };
  let state = { ...defaults };
  try {
    const s = JSON.parse(localStorage.getItem(KEY));
    if (s && Array.isArray(s.games)) state = { ...defaults, ...s };
  } catch (e) {}
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} };

  let selected = null, hoverId = null, layout = [], showAll = false, showDone = false, query = "";
  const $ = id => document.getElementById(id);
  const r1 = n => Math.round(n * 10) / 10;
  const fmtH = h => r1(h).toLocaleString("es-ES") + " h";
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /* ---------- reglas del juego ---------- */
  const leftOf = g => (g.left != null ? g.left : Math.max(0, r1(state.avgLen - g.played)));
  const isDone = g => g.done === true || (g.done == null && g.left == null && g.played >= state.avgLen);
  const pending = () => state.games.filter(g => !isDone(g) && !g.hidden);
  const progress = g => { const l = leftOf(g); return g.played + l > 0 ? g.played / (g.played + l) : 0; };

  function finish() {
    const h = pending().reduce((a, g) => a + leftOf(g), 0);
    const d = new Date();
    d.setDate(d.getDate() + Math.ceil((h / state.pace) * 7));
    return { h, d };
  }
  const monthYear = d => d.toLocaleDateString("es-ES", { month: "long", year: "numeric" });

  /* ---------- ciudad ---------- */
  function rand(seed) { const x = Math.sin(seed * 9301 + 49297) * 233280; return x - Math.floor(x); }

  function drawCity(c, W, H, opts) {
    opts = opts || {};
    const top = opts.top || 96, ground = H - (opts.groundH || 22);
    const sky = c.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, "#0a1020"); sky.addColorStop(1, "#1d2a45");
    c.fillStyle = sky; c.fillRect(0, 0, W, H);
    for (let i = 0; i < 90; i++) {
      c.fillStyle = `rgba(232,237,246,${0.2 + rand(i) * 0.6})`;
      c.fillRect(rand(i + 3) * W, rand(i + 7) * (ground - 40) * 0.6, 1.3, 1.3);
    }
    const mx = W - 60, my = 62;
    c.fillStyle = "#f3e7c9"; c.beginPath(); c.arc(mx, my, 18, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#0a1020"; c.beginPath(); c.arc(mx + 8, my - 6, 16, 0, Math.PI * 2); c.fill();

    const gap = 5, minW = 11;
    const maxSlots = Math.max(4, Math.floor((W - 24 + gap) / (minW + gap)));
    let pend = pending().sort((a, b) => leftOf(b) - leftOf(a)).slice(0, maxSlots);
    const parks = state.games.filter(g => isDone(g) && !g.hidden).slice(0, Math.max(0, Math.min(8, maxSlots - pend.length)));
    const items = pend.concat(parks).sort((a, b) => rand(a.id * 7.3) - rand(b.id * 7.3));
    const shown = { pend: pend.length, total: pending().length };

    const maxLeft = Math.max(10, ...pend.map(g => leftOf(g) + g.played * 0.35));
    const totalUnits = items.reduce((a, g) => a + (isDone(g) ? 1.2 : 1), 0) || 1;
    const unit = (W - 24 - gap * Math.max(0, items.length - 1)) / totalUnits;
    let x = 12; const lay = [];

    items.forEach(g => {
      const done = isDone(g);
      const w = Math.max(minW, unit * (done ? 1.2 : 1));
      if (done) {
        c.fillStyle = "#173a2e"; c.fillRect(x, ground - 6, w, 6);
        const trees = w > 26 ? 2 : 1;
        for (let t = 0; t < trees; t++) {
          const tx = x + w * (trees === 1 ? 0.5 : 0.3 + t * 0.4);
          c.fillStyle = "#4a3a2a"; c.fillRect(tx - 1, ground - 14, 2, 8);
          c.fillStyle = "#6fd3a5"; c.beginPath(); c.arc(tx, ground - 17, Math.min(6, w / 3), 0, Math.PI * 2); c.fill();
        }
        lay.push({ id: g.id, x, y: ground - 26, w, h: 26 });
        x += w + gap; return;
      }
      const l = leftOf(g);
      const h = Math.max(26, ((l + g.played * 0.35) / maxLeft) * (ground - top));
      const y = ground - h;
      const hi = g.id === hoverId || g.id === selected;
      c.fillStyle = hi ? "#2e3f63" : "#1a2640"; c.fillRect(x, y, w, h);
      c.fillStyle = "#24334f"; c.fillRect(x, y, w, 3);
      const cols = Math.max(1, Math.floor((w - 4) / 8)), rows = Math.max(1, Math.floor((h - 10) / 10));
      const total = cols * rows, lit = Math.round(total * progress(g));
      const order = [...Array(total).keys()].sort((a, b) => rand(a + g.id * 31) - rand(b + g.id * 31));
      const litSet = new Set(order.slice(0, lit));
      const cw = (w - 4) / cols;
      for (let r = 0; r < rows; r++) for (let k = 0; k < cols; k++) {
        c.fillStyle = litSet.has(r * cols + k) ? "#ffc46b" : "#2c3954";
        c.fillRect(x + 2 + k * cw + 1.5, y + 8 + r * 10, Math.max(2, cw - 3), 5);
      }
      if (g.played === 0) {
        c.strokeStyle = "#ff8a6b"; c.lineWidth = 1.5;
        c.beginPath(); c.moveTo(x + w / 2, y); c.lineTo(x + w / 2, y - 12); c.stroke();
        c.fillStyle = "#ff8a6b"; c.beginPath(); c.arc(x + w / 2, y - 13, 2.5, 0, Math.PI * 2); c.fill();
      }
      lay.push({ id: g.id, x, y: y - 14, w, h: h + 14 });
      x += w + gap;
    });
    c.fillStyle = "#0a0f19"; c.fillRect(0, ground, W, H - ground);
    c.fillStyle = "#2a3a56"; for (let i = 0; i < W; i += 28) c.fillRect(i, ground + 10, 14, 2);
    return { lay, shown };
  }

  let lastShown = { pend: 0, total: 0 };
  function paintCity() {
    const cv = $("city"), dpr = window.devicePixelRatio || 1;
    const W = cv.clientWidth, H = cv.clientHeight;
    cv.width = W * dpr; cv.height = H * dpr;
    const c = cv.getContext("2d"); c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const res = drawCity(c, W, H, { top: W < 600 ? 150 : 96 });
    layout = res.lay; lastShown = res.shown;
  }

  function hit(ev) {
    const r = $("city").getBoundingClientRect(), mx = ev.clientX - r.left, my = ev.clientY - r.top;
    return layout.find(b => mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h);
  }
  function showTip(ev, b) {
    const tip = $("tip");
    if (!b) { tip.hidden = true; return; }
    const g = state.games.find(x => x.id === b.id);
    tip.innerHTML = `<strong>${esc(g.name)}</strong>` + (isDone(g) ? "Terminado" : `${fmtH(g.played)} jugadas · faltan ${fmtH(leftOf(g))}`);
    tip.hidden = false;
    const r = $("city").getBoundingClientRect();
    tip.style.left = Math.max(8, Math.min(ev.clientX - r.left + 12, r.width - 230)) + "px";
    tip.style.top = Math.max(ev.clientY - r.top - 64, 8) + "px";
  }
  $("city").addEventListener("mousemove", ev => {
    const b = hit(ev), id = b ? b.id : null;
    if (id !== hoverId) { hoverId = id; paintCity(); }
    showTip(ev, b);
  });
  $("city").addEventListener("mouseleave", () => { hoverId = null; $("tip").hidden = true; paintCity(); });
  $("city").addEventListener("click", ev => {
    const b = hit(ev);
    selected = b ? b.id : null;
    showTip(ev, b);
    render();
    if (b) {
      const row = document.querySelector(`tr[data-id="${b.id}"]`);
      if (row) row.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  });

  /* ---------- paneles ---------- */
  const PAGE = 40;
  function render() {
    const { h, d } = finish();
    const p = pending();
    const unopened = p.filter(g => g.played === 0);

    $("sourceTag").textContent = state.source === "steam" ? (state.persona ? `Ciudad de ${state.persona}` : "Tu Steam")
      : state.source === "manual" ? "Tu ciudad" : "Ciudad de ejemplo";

    if (p.length) {
      $("verdict").innerHTML = `A este ritmo terminarías tu backlog en <b>${esc(monthYear(d))}</b>`;
      let sub = `${p.length} juegos pendientes · ${Math.round(h).toLocaleString("es-ES")} h · ${state.pace} h a la semana`;
      if (lastShown.total > lastShown.pend) sub += ` · se ven los ${lastShown.pend} más grandes`;
      $("verdictSub").textContent = sub;
    } else {
      $("verdict").textContent = state.games.length ? "Backlog terminado. Tu ciudad es un parque." : "Ciudad vacía. Añade tu primer juego abajo.";
      $("verdictSub").textContent = "";
    }

    $("sHours").innerHTML = Math.round(h).toLocaleString("es-ES") + "<small>horas</small>";
    $("sUnopened").innerHTML = unopened.length + "<small>juegos</small>";
    const paid = unopened.reduce((a, g) => a + (+g.price || 0), 0);
    $("sUnopenedSub").textContent = paid > 0
      ? `sin abrir nunca · ${paid.toLocaleString("es-ES", { style: "currency", currency: "EUR" })} pagados`
      : "que nunca has abierto";
    $("paceVal").textContent = state.pace + " h"; $("pace").value = state.pace;
    $("avgVal").textContent = state.avgLen + " h"; $("avgLen").value = state.avgLen;

    const opts = [1, 2, 4, 8];
    $("chips").innerHTML = opts.map(o => `<button type="button" class="chip" aria-pressed="${state.nightPick === o}" data-h="${o}">${o} h</button>`).join("");
    const lim = state.nightPick * 1.15;
    const fits = p.filter(g => leftOf(g) <= lim).sort((a, b) => leftOf(b) - leftOf(a)).slice(0, 4);
    const close = p.filter(g => leftOf(g) > lim).sort((a, b) => leftOf(a) - leftOf(b)).slice(0, 3);
    $("picks").innerHTML = fits.length
      ? fits.map(g => `<div class="pick"><span>Terminas <strong>${esc(g.name)}</strong></span><span>${fmtH(leftOf(g))}</span></div>`).join("")
      : `<p class="empty">Ningún juego se termina en ${state.nightPick} h. Los que más cerca están:</p>` +
        close.map(g => `<div class="pick"><span>${esc(g.name)}</span><span>${fmtH(leftOf(g))}</span></div>`).join("");

    const heavy = [...p].sort((a, b) => leftOf(b) - leftOf(a)).slice(0, 4);
    $("heavy").innerHTML = heavy.length
      ? heavy.map(g => `<div class="pick"><span>${esc(g.name)}</span><span>${h ? Math.round((leftOf(g) / h) * 100) : 0}% del total</span></div>`).join("")
      : '<p class="empty">Nada pendiente.</p>';

    renderTable();
    paintCity();
  }

  function renderTable() {
    const q = query.trim().toLowerCase();
    let rows = state.games.filter(g => !g.hidden && (showDone || !isDone(g)) && (!q || g.name.toLowerCase().includes(q)));
    rows.sort((a, b) => isDone(a) - isDone(b) || leftOf(b) - leftOf(a));
    const total = rows.length;
    if (!showAll) rows = rows.slice(0, PAGE);
    $("tbody").innerHTML = rows.map(g => {
      const done = isDone(g);
      const prog = done ? 100 : Math.round(progress(g) * 100);
      const st = done ? '<span class="pill ok">Terminado</span>' : g.played === 0 ? '<span class="pill new">Sin abrir</span>' : "";
      const leftCell = done ? "—" : `<input type="number" min="0" step="0.5" value="${leftOf(g)}" data-left="${g.id}" aria-label="Horas que faltan en ${esc(g.name)}">`;
      return `<tr data-id="${g.id}" class="${g.id === selected ? "sel" : ""}">
        <td>${esc(g.name)} ${st}</td>
        <td class="num">${fmtH(g.played)}</td>
        <td class="num">${leftCell}</td>
        <td><div class="bar"><i style="width:${prog}%"></i></div></td>
        <td><div class="row" style="flex-wrap:nowrap">${done
          ? `<button type="button" data-act="undo" data-id="${g.id}">Reabrir</button>`
          : `<button type="button" data-act="done" data-id="${g.id}">Terminado</button>`}
          <button type="button" data-act="hide" data-id="${g.id}" aria-label="Quitar ${esc(g.name)}">Quitar</button></div></td></tr>`;
    }).join("") || `<tr><td colspan="5" class="empty">${q ? "Ningún juego coincide con la búsqueda." : "Añade tu primer juego con el formulario de abajo."}</td></tr>`;
    $("more").hidden = showAll || total <= PAGE;
    $("more").textContent = `Mostrar los ${total} juegos`;
    $("showDone").setAttribute("aria-pressed", String(showDone));
    $("showDone").textContent = showDone ? "Ocultar terminados" : "Mostrar terminados";
  }

  /* ---------- eventos ---------- */
  $("pace").addEventListener("input", e => { state.pace = +e.target.value; save(); render(); });
  $("avgLen").addEventListener("input", e => { state.avgLen = +e.target.value; save(); render(); });
  $("chips").addEventListener("click", e => { const b = e.target.closest("[data-h]"); if (!b) return; state.nightPick = +b.dataset.h; save(); render(); });
  $("search").addEventListener("input", e => { query = e.target.value; renderTable(); });
  $("showDone").addEventListener("click", () => { showDone = !showDone; renderTable(); });
  $("more").addEventListener("click", () => { showAll = true; renderTable(); });

  $("tbody").addEventListener("change", e => {
    const id = +e.target.dataset.left; if (!id) return;
    const g = state.games.find(x => x.id === id);
    const v = Math.max(0, +e.target.value || 0);
    g.left = v; if (v === 0) g.done = true;
    save(); render();
  });
  $("tbody").addEventListener("click", e => {
    const b = e.target.closest("button[data-act]"); if (!b) return;
    const g = state.games.find(x => x.id === +b.dataset.id); if (!g) return;
    if (b.dataset.act === "done") { g.done = true; toast(`${g.name} terminado. Un parque nuevo en la ciudad.`); }
    if (b.dataset.act === "undo") { g.done = false; if (leftOf(g) <= 0) g.left = 5; }
    if (b.dataset.act === "hide") { g.hidden = true; toast(`${g.name} quitado de la ciudad.`); }
    if (state.source === "sample") state.source = "manual";
    save(); render();
  });

  $("add").addEventListener("submit", e => {
    e.preventDefault();
    const name = $("fName").value.trim(), left = +$("fLeft").value;
    if (!name || !(left > 0)) return;
    const id = Math.max(0, ...state.games.map(g => g.id)) + 1;
    state.games.push({ id, name, played: +$("fPlayed").value || 0, left, price: +$("fPrice").value || 0, done: false });
    if (state.source === "sample") state.source = "manual";
    save(); e.target.reset(); $("fPlayed").value = 0; $("fPrice").value = 0;
    selected = id; render(); toast(`${name} construido.`);
  });
  $("reset").addEventListener("click", () => { state = { ...state, games: sampleGames(), source: "sample", persona: "", profile: "" }; selected = null; save(); render(); });
  $("clear").addEventListener("click", () => { state = { ...state, games: [], source: "manual", persona: "", profile: "" }; selected = null; save(); render(); $("fName").focus(); });

  $("spin").addEventListener("click", () => {
    const p = pending(), el = $("roul");
    if (!p.length) { el.textContent = "No queda nada pendiente"; return; }
    const final = p[Math.floor(Math.random() * p.length)];
    const done = () => { el.classList.remove("spin"); el.textContent = final.name; selected = final.id; render(); };
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return done();
    let n = 0; el.classList.add("spin");
    const t = setInterval(() => {
      el.textContent = p[Math.floor(Math.random() * p.length)].name;
      if (++n > 16) { clearInterval(t); done(); }
    }, 70);
  });

  /* ---------- Steam ---------- */
  async function loadSteam(input, fromLink) {
    const btn = $("steamBtn"), err = $("steamErr");
    err.hidden = true; btn.disabled = true; btn.textContent = "Construyendo...";
    try {
      const r = await fetch("/api/steam?id=" + encodeURIComponent(input));
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.error || "No se pudo cargar tu Steam.");
      if (!data.games.length) throw new Error("Ese perfil no tiene juegos de pago en su biblioteca.");
      const prev = new Map(state.source === "steam" ? state.games.filter(g => g.appid).map(g => [g.appid, g]) : []);
      state.games = data.games.map((g, i) => {
        const old = prev.get(g.appid) || {};
        return { id: i + 1, appid: g.appid, name: g.name, played: r1(g.minutes / 60), left: old.left != null ? old.left : null, done: old.done != null ? old.done : null, hidden: !!old.hidden };
      });
      state.source = "steam"; state.persona = data.persona || ""; state.profile = input;
      selected = null; showAll = false; save(); render();
      if (!fromLink) toast(`${data.games.length} juegos cargados.`);
      try { history.replaceState(null, "", "?u=" + encodeURIComponent(data.vanity || data.steamid)); } catch (e) {}
    } catch (e) {
      err.textContent = e.message; err.hidden = false;
    } finally {
      btn.disabled = false; btn.textContent = "Construir mi ciudad";
    }
  }
  $("steamForm").addEventListener("submit", e => {
    e.preventDefault();
    const v = $("steamInput").value.trim();
    if (!v) { $("steamErr").textContent = "Escribe tu nombre de perfil de Steam o pega el enlace."; $("steamErr").hidden = false; return; }
    loadSteam(v, false);
  });

  /* ---------- compartir ---------- */
  const baseUrl = () => (CFG.siteUrl || (location.origin + location.pathname)).replace(/\/index\.html$/, "").replace(/\/$/, "");
  function shareLink() {
    const u = new URLSearchParams(location.search).get("u");
    return state.source === "steam" && u ? `${baseUrl()}/?u=${encodeURIComponent(u)}` : baseUrl() + "/";
  }
  $("copyLink").addEventListener("click", () => {
    const { h, d } = finish();
    const txt = `Mi Backlog City: ${pending().length} juegos pendientes, ${Math.round(h)} horas. Lo termino en ${monthYear(d)}. ¿Y tú? ${shareLink()}`;
    navigator.clipboard.writeText(txt).then(() => toast("Enlace copiado. Pégalo donde quieras."))
      .catch(() => { $("roul").textContent = txt; toast("Copia el texto de la ruleta."); });
  });
  $("dlImg").addEventListener("click", () => {
    const W = 1200, H = 630, cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const c = cv.getContext("2d");
    drawCity(c, W, H, { top: 230, groundH: 70 });
    const { h, d } = finish();
    c.fillStyle = "rgba(10,16,32,.55)"; c.fillRect(0, 0, W, 200);
    c.fillStyle = "#e8edf6"; c.font = "700 56px 'Chakra Petch', sans-serif";
    c.fillText(state.persona ? `La ciudad de ${state.persona}` : "Mi Backlog City", 48, 88);
    c.font = "500 34px 'IBM Plex Sans', sans-serif"; c.fillStyle = "#ffc46b";
    c.fillText(pending().length ? `Termino mi backlog en ${monthYear(d)}` : "Backlog terminado", 48, 140);
    c.fillStyle = "#93a1ba"; c.font = "500 24px 'IBM Plex Sans', sans-serif";
    c.fillText(`${pending().length} juegos · ${Math.round(h).toLocaleString("es-ES")} horas pendientes`, 48, 180);
    if (CFG.siteUrl) {
      c.fillStyle = "#e8edf6"; c.font = "500 24px 'IBM Plex Mono', monospace";
      c.fillText(CFG.siteUrl.replace(/^https?:\/\//, ""), 48, H - 26);
    }
    cv.toBlob(b => {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(b); a.download = "mi-backlog-city.png";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    }, "image/png");
  });

  /* ---------- anuncios y apoyo ---------- */
  if (CFG.adsenseClient && CFG.adsenseSlot) {
    const s = document.createElement("script");
    s.async = true; s.crossOrigin = "anonymous";
    s.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=" + encodeURIComponent(CFG.adsenseClient);
    document.head.appendChild(s);
    const slot = $("adSlot");
    slot.innerHTML = `<ins class="adsbygoogle" style="display:block" data-ad-client="${esc(CFG.adsenseClient)}" data-ad-slot="${esc(CFG.adsenseSlot)}" data-ad-format="auto" data-full-width-responsive="true"></ins>`;
    slot.hidden = false;
    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) {}
  }
  const support = [];
  if (CFG.donateUrl) support.push(`<a class="btn" href="${esc(CFG.donateUrl)}" target="_blank" rel="noopener">Invítame a un café</a>`);
  if (CFG.storeAffiliateUrl) support.push(`<a class="btn" href="${esc(CFG.storeAffiliateUrl)}" target="_blank" rel="noopener sponsored">Ofertas en juegos</a>`);
  if (support.length) { $("support").innerHTML = support.join(""); $("support").hidden = false; }

  /* ---------- arranque ---------- */
  let toastT;
  function toast(m) { const t = $("toast"); t.textContent = m; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => (t.hidden = true), 2600); }
  window.addEventListener("resize", paintCity);
  if (document.fonts) document.fonts.ready.then(render);
  render();

  const shared = new URLSearchParams(location.search).get("u");
  if (shared) { $("steamInput").value = shared; loadSteam(shared, true); }
})();

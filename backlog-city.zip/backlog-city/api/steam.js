// Función de servidor (Vercel). Recibe un perfil de Steam y devuelve sus juegos.
// Necesita la variable de entorno STEAM_API_KEY (se configura en Vercel).

const API = "https://api.steampowered.com";

function parseInput(raw) {
  const s = String(raw || "").trim();
  let m = s.match(/steamcommunity\.com\/profiles\/(\d{17})/i);
  if (m) return { id: m[1] };
  m = s.match(/steamcommunity\.com\/id\/([^\/?#\s]+)/i);
  if (m) return { vanity: m[1] };
  if (/^\d{17}$/.test(s)) return { id: s };
  if (/^[A-Za-z0-9_-]{2,32}$/.test(s)) return { vanity: s };
  return null;
}

async function getJSON(url) {
  const r = await fetch(url, { headers: { "User-Agent": "BacklogCity/1.0" } });
  if (!r.ok) throw new Error("steam_" + r.status);
  return r.json();
}

export default async function handler(req, res) {
  const key = process.env.STEAM_API_KEY;
  if (!key) {
    return res.status(500).json({ error: "Falta configurar la clave de Steam en el servidor." });
  }

  const input = parseInput(req.query.id);
  if (!input) {
    return res.status(400).json({ error: "Escribe tu nombre de perfil de Steam o pega el enlace a tu perfil." });
  }

  try {
    let steamid = input.id;
    if (!steamid) {
      const v = await getJSON(`${API}/ISteamUser/ResolveVanityURL/v1/?key=${key}&vanityurl=${encodeURIComponent(input.vanity)}`);
      if (!v.response || v.response.success !== 1) {
        return res.status(404).json({ error: "No encontramos ese perfil. Prueba pegando el enlace completo a tu perfil de Steam." });
      }
      steamid = v.response.steamid;
    }

    const [owned, summary] = await Promise.all([
      getJSON(`${API}/IPlayerService/GetOwnedGames/v1/?key=${key}&steamid=${steamid}&include_appinfo=1&include_played_free_games=0`),
      getJSON(`${API}/ISteamUser/GetPlayerSummaries/v2/?key=${key}&steamids=${steamid}`)
    ]);

    const player = (summary.response && summary.response.players && summary.response.players[0]) || {};
    const list = owned.response && owned.response.games;

    if (!Array.isArray(list)) {
      return res.status(403).json({
        error: "Tu lista de juegos es privada. En Steam ve a Perfil > Editar perfil > Privacidad y pon «Detalles del juego» en Público."
      });
    }

    const games = list
      .filter(g => g.name)
      .map(g => ({ appid: g.appid, name: g.name, minutes: g.playtime_forever || 0 }));

    res.setHeader("Cache-Control", "s-maxage=1800, stale-while-revalidate=3600");
    return res.status(200).json({
      steamid,
      persona: player.personaname || "",
      vanity: input.vanity || "",
      games
    });
  } catch (e) {
    return res.status(502).json({ error: "Steam no responde ahora mismo. Vuelve a intentarlo en un minuto." });
  }
}

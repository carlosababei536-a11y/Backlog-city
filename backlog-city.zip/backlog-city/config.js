// Ajustes de la web. Rellena estos valores cuando los tengas; si se quedan vacíos, no se muestra nada.
window.BC_CONFIG = {
  // Dirección pública de tu web, sin barra final. Ej: "https://backlogcity.com"
  siteUrl: "",
  // Tu ID de Google AdSense. Ej: "ca-pub-1234567890123456"
  adsenseClient: "",
  // ID del bloque de anuncio que crees en AdSense. Ej: "1234567890"
  adsenseSlot: "",
  // Enlace a tu página de donaciones (Ko-fi, Buy Me a Coffee...). Ej: "https://ko-fi.com/tunombre"
  donateUrl: "",
  // Enlace de afiliado a una tienda de juegos (Instant Gaming, etc.). Ej: "https://www.instant-gaming.com/?igr=tunombre"
  storeAffiliateUrl: "",
  // Email de contacto para la página de privacidad
  contactEmail: ""
};
